-- =====================================================================
-- RigCheck Pro - Esquema de Base de Datos (SQLite)
-- =====================================================================
-- Versión portable en SQLite para que el proyecto se ejecute sin
-- necesidad de instalar un servidor MySQL.
-- =====================================================================

CREATE TABLE IF NOT EXISTS cpus (
    id_cpu          INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre          TEXT     NOT NULL,
    socket          TEXT     NOT NULL,
    consumo_watts   INTEGER  NOT NULL,
    power_score     INTEGER  NOT NULL,
    precio_cop      REAL     NOT NULL
);

CREATE TABLE IF NOT EXISTS motherboards (
    id_mobo         INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre          TEXT     NOT NULL,
    socket          TEXT     NOT NULL,
    formato         TEXT     NOT NULL,
    precio_cop      REAL     NOT NULL
);

CREATE TABLE IF NOT EXISTS gpus (
    id_gpu              INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre              TEXT     NOT NULL,
    vram_gb             INTEGER  NOT NULL,
    consumo_min_fuente  INTEGER  NOT NULL,
    power_score         INTEGER  NOT NULL,
    precio_cop          REAL     NOT NULL
);

CREATE TABLE IF NOT EXISTS reglas_compatibilidad (
    id_regla            INTEGER PRIMARY KEY AUTOINCREMENT,
    componente_a        TEXT,
    componente_b        TEXT,
    descripcion_error   TEXT
);
