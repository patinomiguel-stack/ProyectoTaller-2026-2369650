-- =====================================================================
-- RigCheck Pro - Datos de ejemplo (compatibles con MySQL y SQLite)
-- Precios en pesos colombianos (COP) referenciales del mercado local.
-- =====================================================================

-- ---------- PROCESADORES (CPUs) ----------
INSERT INTO cpus (nombre, socket, consumo_watts, power_score, precio_cop) VALUES
    ('AMD Ryzen 5 7600',         'AM5',     65,  78, 1050000),
    ('AMD Ryzen 7 7800X3D',      'AM5',    120,  95, 2200000),
    ('AMD Ryzen 5 5600',         'AM4',     65,  65,  650000),
    ('Intel Core i5-13600K',     'LGA1700', 125,  88, 1450000),
    ('Intel Core i7-13700K',     'LGA1700', 125,  92, 1850000),
    ('Intel Core i3-12100F',     'LGA1700',  58,  55,  520000);

-- ---------- PLACAS BASE (Motherboards) ----------
INSERT INTO motherboards (nombre, socket, formato, precio_cop) VALUES
    ('ASUS ROG Strix B650-A',    'AM5',     'ATX',        950000),
    ('Gigabyte B650 Aorus Elite','AM5',     'ATX',        820000),
    ('MSI B550-A Pro',           'AM4',     'ATX',        580000),
    ('ASUS Prime Z790-P',        'LGA1700', 'ATX',       1100000),
    ('MSI Pro B760M-A',          'LGA1700', 'Micro-ATX',  650000),
    ('Gigabyte H610M-S2H',       'LGA1700', 'Micro-ATX',  410000);

-- ---------- TARJETAS GRÁFICAS (GPUs) ----------
INSERT INTO gpus (nombre, vram_gb, consumo_min_fuente, power_score, precio_cop) VALUES
    ('NVIDIA RTX 4060',          8,   550,  72, 1450000),
    ('NVIDIA RTX 4070 Super',   12,   650,  88, 2950000),
    ('NVIDIA RTX 4090',         24,   850,  99, 9500000),
    ('AMD Radeon RX 7600',       8,   550,  68, 1250000),
    ('AMD Radeon RX 7800 XT',   16,   700,  86, 2700000),
    ('NVIDIA GTX 1660 Super',    6,   450,  48,  780000);

-- ---------- REGLAS DE COMPATIBILIDAD ----------
INSERT INTO reglas_compatibilidad (componente_a, componente_b, descripcion_error) VALUES
    ('cpu', 'motherboard', 'El socket del procesador no coincide con el de la placa base. Son fisicamente incompatibles.'),
    ('cpu', 'gpu',         'El procesador es demasiado debil para esta GPU: se generara cuello de botella.'),
    ('gpu', 'cpu',         'La tarjeta grafica limita el potencial del procesador (CPU sobredimensionada).');
