-- =====================================================================
-- RigCheck Pro - Esquema de Base de Datos (MySQL)
-- Proyecto Integrador - Universidad del Valle
-- =====================================================================
-- Este archivo contiene la versión MySQL original del esquema, con las
-- correcciones del tipo de dato del precio en pesos colombianos (COP).
-- Para una ejecución rápida sin instalar MySQL, usa data/schema_sqlite.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS rigcheck_db
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE rigcheck_db;

-- 1. Procesadores (CPUs)
CREATE TABLE IF NOT EXISTS cpus (
    id_cpu          INT AUTO_INCREMENT PRIMARY KEY,
    nombre          VARCHAR(100)   NOT NULL,
    socket          VARCHAR(20)    NOT NULL,   -- Ej: 'AM5', 'LGA1700'
    consumo_watts   INT            NOT NULL,
    power_score     INT            NOT NULL,   -- Puntaje de rendimiento (1-100)
    precio_cop      DECIMAL(12,2)  NOT NULL    -- Precio en pesos colombianos
);

-- 2. Placas Base (Motherboards)
CREATE TABLE IF NOT EXISTS motherboards (
    id_mobo         INT AUTO_INCREMENT PRIMARY KEY,
    nombre          VARCHAR(100)   NOT NULL,
    socket          VARCHAR(20)    NOT NULL,   -- Debe coincidir con el socket de la CPU
    formato         VARCHAR(10)    NOT NULL,   -- Ej: ATX, Micro-ATX, Mini-ITX
    precio_cop      DECIMAL(12,2)  NOT NULL
);

-- 3. Tarjetas Gráficas (GPUs)
CREATE TABLE IF NOT EXISTS gpus (
    id_gpu              INT AUTO_INCREMENT PRIMARY KEY,
    nombre              VARCHAR(100)   NOT NULL,
    vram_gb             INT            NOT NULL,
    consumo_min_fuente  INT            NOT NULL,  -- Watts mínimos recomendados
    power_score         INT            NOT NULL,  -- Puntaje de rendimiento (1-100)
    precio_cop          DECIMAL(12,2)  NOT NULL
);

-- 4. Reglas de compatibilidad (mensajes explicativos)
CREATE TABLE IF NOT EXISTS reglas_compatibilidad (
    id_regla            INT AUTO_INCREMENT PRIMARY KEY,
    componente_a        VARCHAR(50),
    componente_b        VARCHAR(50),
    descripcion_error   TEXT
);
