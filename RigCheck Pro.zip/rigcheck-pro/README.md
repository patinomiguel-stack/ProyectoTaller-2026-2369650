# RigCheck Pro

> **Asesor inteligente de compatibilidad de hardware para PC en Colombia.**
> Proyecto Integrador — Universidad del Valle.
> Componente 3: *Algoritmia e Implementación en Código (RA3)*.

RigCheck Pro evita que un usuario sin conocimientos técnicos cometa errores
costosos al ensamblar su computador: valida la **compatibilidad física** de
los componentes, detecta **cuellos de botella** de rendimiento, estima el
**consumo eléctrico** y calcula el **presupuesto total en pesos colombianos**.

## Estructura del repositorio

```
rigcheck-pro/
├── src/
│   ├── backend/                Código Python (motor de validación)
│   │   ├── rigcheck_engine.py  Algoritmo ValidarRig (núcleo del proyecto)
│   │   ├── database.py         Capa de acceso a datos (SQLite + MySQL)
│   │   ├── main.py             CLI de demostración
│   │   └── api.py              API HTTP opcional (Flask) para el frontend
│   └── frontend/               Vitrina HTML/CSS/JS
│       ├── index.html
│       ├── styles.css
│       └── script.js
├── data/                       Esquemas SQL y datos de ejemplo
│   ├── schema_mysql.sql        Esquema original (MySQL)
│   ├── schema_sqlite.sql       Esquema portable (SQLite)
│   └── seed.sql                Componentes con precios COP
├── docs/                       Documentación del componente
│   ├── pseudocodigo.md
│   ├── diagrama_flujo.md
│   ├── diagrama_flujo.png
│   └── manual_usuario.md
├── requirements.txt
└── README.md
```

## Instalación rápida

```bash
cd rigcheck-pro
python -m venv .venv && source .venv/bin/activate    # opcional
pip install -r requirements.txt
python -m src.backend.main                            # menú interactivo
```

> En la primera ejecución se crea `data/rigcheck.db` con los datos de ejemplo.
> No requiere MySQL.

## Ejecución de la interfaz web

```bash
python -m src.backend.api          # backend en http://localhost:5000
# Luego abre src/frontend/index.html en el navegador
```

## Algoritmo

El algoritmo central, **`ValidarRig`**, está documentado en tres formatos
equivalentes y verificables:

1. **Diseño**: este README + `docs/manual_usuario.md`.
2. **Pseudocódigo**: `docs/pseudocodigo.md`.
3. **Diagrama de flujo**: `docs/diagrama_flujo.png`.
4. **Implementación**: `src/backend/rigcheck_engine.py`.

Cumple con los requisitos del componente:

- **Estructura de selección**: validación de socket y clasificación del ratio.
- **Estructura de ciclo**: cálculo iterativo del presupuesto total.
- **Entradas/salidas claras**: tres componentes y un reporte estructurado.

## Propuesta de valor

- **Precios reales en pesos colombianos** (no dólares ni promedios globales).
- **Explica el “por qué”** de las incompatibilidades (no solo dice "error").
- **Exporta a Excel** un reporte profesional listo para compartir.
- **Funciona offline** una vez sembrada la base de datos.

## Stack técnico

- **Backend**: Python 3.10+, `pandas`, `openpyxl`, `Flask` (opcional).
- **Persistencia**: SQLite por defecto, MySQL opcional.
- **Frontend**: HTML5 + CSS3 + JavaScript vanilla (sin frameworks).

## Licencia

Uso académico — Universidad del Valle, 2026.
