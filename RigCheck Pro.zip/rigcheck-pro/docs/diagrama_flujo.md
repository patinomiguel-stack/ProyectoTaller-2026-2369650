# Diagrama de Flujo — `ValidarRig`

El diagrama de flujo formal del algoritmo se encuentra en este mismo
directorio como imagen:

![Diagrama de flujo de ValidarRig](diagrama_flujo.png)

## Lectura del diagrama

1. **Inicio → Entrada**: el algoritmo recibe `cpu`, `gpu` y `placa_base`.
2. **Decisión de socket** (`cpu.socket == placa_base.socket?`):
   - **No** → muestra *"Error de socket"* y retorna `Falso`.
   - **Sí** → continúa.
3. **Cálculo del ratio de rendimiento** (`power_score_cpu / power_score_gpu`).
4. **Decisión de cuello de botella**:
   - `ratio < 0.85` → *"Cuello de botella CPU"*.
   - En caso contrario, evalúa `ratio > 1.25`:
     - **Sí** → *"GPU limita CPU"*.
     - **No** → *"Configuración equilibrada"*.
5. **Exportar a Excel** (en todas las ramas válidas).
6. **Fin**.

> El diagrama fue construido en `draw.io` y cumple con los requisitos del
> Componente 3 (al menos una decisión y una estructura iterativa, esta
> última implementada en el cálculo del presupuesto total — ver pseudocódigo).
