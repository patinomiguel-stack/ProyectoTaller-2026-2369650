# Pseudocódigo — Algoritmo `ValidarRig`

Este pseudocódigo es la representación formal del algoritmo central de RigCheck Pro.
La implementación correspondiente se encuentra en `src/backend/rigcheck_engine.py`
y el diagrama de flujo en `docs/diagrama_flujo.png`.

```text
ALGORITMO ValidarRig
  ENTRADA: cpu_seleccionada, gpu_seleccionada, placa_base, watts_fuente (opcional)
  SALIDA:  reporte (compatibilidad, advertencias, presupuesto, ratio)

  // 1. Validación de Compatibilidad Física
  SI cpu_seleccionada.socket != placa_base.socket ENTONCES
      MOSTRAR "Error: el socket del procesador no coincide con la placa base."
      RETORNAR Falso
  FIN SI

  // 2. Cálculo de Cuello de Botella (ratio CPU/GPU)
  puntuacion_cpu  = cpu_seleccionada.power_score
  puntuacion_gpu  = gpu_seleccionada.power_score
  ratio_rendimiento = puntuacion_cpu / puntuacion_gpu

  SI ratio_rendimiento < 0.85 ENTONCES
      MOSTRAR "Advertencia: cuello de botella detectado (CPU débil para esta GPU)."
  SINO SI ratio_rendimiento > 1.25 ENTONCES
      MOSTRAR "Advertencia: la GPU limita el potencial de tu CPU."
  SINO
      MOSTRAR "Configuración equilibrada: potencia óptima."
  FIN SI

  // 3. Validación eléctrica (extensión)
  consumo_estimado = cpu_seleccionada.consumo_watts + gpu_seleccionada.consumo_min_fuente
  SI watts_fuente != NULO Y watts_fuente < consumo_estimado ENTONCES
      MOSTRAR "Advertencia: la fuente es insuficiente. Recomendado: " + consumo_estimado + " W."
  FIN SI

  // 4. Cálculo del presupuesto total en COP (recorre los 3 componentes)
  componentes = [cpu_seleccionada, gpu_seleccionada, placa_base]
  presupuesto_total = 0
  PARA CADA componente EN componentes HACER
      presupuesto_total = presupuesto_total + componente.precio_cop
  FIN PARA

  // 5. Exportación de resultados
  LLAMAR ExportarExcel(cpu_seleccionada, gpu_seleccionada, placa_base, presupuesto_total)
  RETORNAR Verdadero
FIN ALGORITMO
```

## Cumplimiento del Componente 3 (RA3)

- **Estructura de selección**: bloques `SI / SINO SI / SINO` para validar socket
  y clasificar el ratio de rendimiento.
- **Estructura de ciclo**: `PARA CADA` que recorre los componentes y acumula
  el presupuesto total.
- **Entradas y salidas claras**: tres componentes obligatorios y una fuente
  opcional; el algoritmo retorna un reporte estructurado.
