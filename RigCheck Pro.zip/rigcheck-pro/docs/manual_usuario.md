# Manual de Usuario — RigCheck Pro

## ¿Qué es RigCheck Pro?

RigCheck Pro es un asesor inteligente que valida la **compatibilidad** entre
CPU, GPU y placa base, detecta **cuellos de botella** de rendimiento, estima
el **consumo eléctrico** y calcula el **presupuesto total en pesos
colombianos** de la configuración elegida.

## Ejecución rápida (sin instalar MySQL)

1. Abre una terminal en la carpeta `rigcheck-pro/`.
2. Crea un entorno virtual (opcional pero recomendado):
   ```bash
   python -m venv .venv
   source .venv/bin/activate    # En Windows: .venv\Scripts\activate
   ```
3. Instala las dependencias:
   ```bash
   pip install -r requirements.txt
   ```
4. Ejecuta el módulo desde la línea de comandos:
   ```bash
   python -m src.backend.main
   ```
   El sistema mostrará el catálogo de componentes, te pedirá los IDs y
   generará un reporte `Asesoria_RigCheck.xlsx`.

> En la primera ejecución se crea automáticamente la base de datos SQLite
> en `data/rigcheck.db` con los componentes de ejemplo del `seed.sql`.

## Ejecución con interfaz web

1. Inicia el servidor backend:
   ```bash
   python -m src.backend.api
   ```
2. Abre `src/frontend/index.html` en tu navegador (basta con doble clic).
3. Selecciona los componentes, presiona **Validar configuración** y opcionalmente
   **Exportar a Excel**.

## Uso del esquema MySQL original

Si deseas usar el esquema MySQL original del Componente 3:

1. Importa `data/schema_mysql.sql` y `data/seed.sql` en tu servidor MySQL.
2. Define las variables de entorno antes de ejecutar el módulo:
   ```bash
   export RIGCHECK_DB=mysql
   export RIGCHECK_MYSQL_USER=root
   export RIGCHECK_MYSQL_PASSWORD=tu_password
   export RIGCHECK_MYSQL_DB=rigcheck_db
   python -m src.backend.main
   ```

## Interpretación del resultado

| Indicador               | Significado                                                     |
| ----------------------- | --------------------------------------------------------------- |
| **Compatible: Sí / No** | Resultado de la validación física de socket.                    |
| **Ratio CPU/GPU**       | Cociente `power_score_cpu / power_score_gpu`.                    |
| **< 0.85**              | CPU débil → cuello de botella en juegos / cargas pesadas.        |
| **0.85 – 1.25**         | Configuración balanceada — recomendada.                          |
| **> 1.25**              | GPU limita a la CPU → conviene subir de gama la GPU.             |
| **Presupuesto total**   | Suma de los precios de CPU + GPU + placa base en COP.            |

## Salida en Excel

El archivo `Asesoria_RigCheck.xlsx` contiene dos hojas:

- **Resumen**: estado, balance, ratio, presupuesto y mensajes.
- **Componentes**: ficha técnica de la CPU, GPU y placa base elegidas.
