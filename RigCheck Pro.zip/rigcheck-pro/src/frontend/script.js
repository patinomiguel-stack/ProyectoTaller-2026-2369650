// RigCheck Pro - Frontend
// Consume la API expuesta por src/backend/api.py
// (asume que el backend corre en http://localhost:5000)

const API = "http://localhost:5000/api";

const $ = (id) => document.getElementById(id);

const formatCOP = (n) =>
    "$" + Number(n || 0).toLocaleString("es-CO", { maximumFractionDigits: 0 }) + " COP";

async function cargarCatalogo() {
    try {
        const res = await fetch(`${API}/catalogo`);
        if (!res.ok) throw new Error("No se pudo cargar el catalogo");
        const data = await res.json();

        llenarSelect($("cpu"), data.cpus, "id_cpu", (c) => `${c.nombre} (${c.socket})`);
        llenarSelect($("gpu"), data.gpus, "id_gpu", (g) => `${g.nombre} - ${g.vram_gb}GB`);
        llenarSelect($("mobo"), data.motherboards, "id_mobo", (m) => `${m.nombre} (${m.socket})`);
    } catch (err) {
        mostrarError(`No se pudo conectar al servidor (${err.message}). Asegurate de ejecutar el backend.`);
    }
}

function llenarSelect(select, items, idKey, label) {
    select.innerHTML = "";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Selecciona...";
    placeholder.disabled = true;
    placeholder.selected = true;
    select.appendChild(placeholder);

    items.forEach((it) => {
        const opt = document.createElement("option");
        opt.value = it[idKey];
        opt.textContent = label(it);
        select.appendChild(opt);
    });
}

function leerFormulario() {
    const id_cpu = parseInt($("cpu").value, 10);
    const id_gpu = parseInt($("gpu").value, 10);
    const id_mobo = parseInt($("mobo").value, 10);
    const wattsRaw = $("watts").value;
    const watts_fuente = wattsRaw ? parseInt(wattsRaw, 10) : null;

    if (!id_cpu || !id_gpu || !id_mobo) {
        mostrarError("Selecciona CPU, GPU y placa base.");
        return null;
    }
    return { id_cpu, id_gpu, id_mobo, watts_fuente };
}

async function validar(ev) {
    ev.preventDefault();
    const datos = leerFormulario();
    if (!datos) return;

    try {
        const res = await fetch(`${API}/validar`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(datos),
        });
        const result = await res.json();
        renderResultado(result);
        $("btn-exportar").disabled = false;
    } catch (err) {
        mostrarError(`Error de validacion: ${err.message}`);
    }
}

function renderResultado(r) {
    const seccion = $("resultado");
    seccion.classList.remove("hidden");

    const banner = $("estado-banner");
    let clase = "ok";
    if (!r.compatible) clase = "error";
    else if ((r.advertencias || []).length > 0) clase = "warn";
    banner.className = `banner ${clase}`;
    banner.textContent = r.estado + (r.compatible ? "" : " - revisa los detalles");

    $("metric-ratio").textContent = r.ratio_rendimiento ?? "-";
    $("metric-balance").textContent = r.diagnostico_balance ?? "-";
    $("metric-presupuesto").textContent = formatCOP(r.presupuesto_total_cop);

    pintarLista($("lista-mensajes"), r.mensajes);
    pintarLista($("lista-advertencias"), r.advertencias);

    seccion.scrollIntoView({ behavior: "smooth", block: "start" });
}

function pintarLista(ul, items) {
    ul.innerHTML = "";
    (items || []).forEach((m) => {
        const li = document.createElement("li");
        li.textContent = m;
        ul.appendChild(li);
    });
    if (!items || items.length === 0) {
        const li = document.createElement("li");
        li.textContent = "(sin entradas)";
        li.style.color = "var(--text-muted)";
        ul.appendChild(li);
    }
}

async function exportar() {
    const datos = leerFormulario();
    if (!datos) return;

    try {
        const res = await fetch(`${API}/exportar`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(datos),
        });
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "Asesoria_RigCheck.xlsx";
        a.click();
        URL.revokeObjectURL(url);
    } catch (err) {
        mostrarError(`Error exportando: ${err.message}`);
    }
}

function mostrarError(msg) {
    const seccion = $("resultado");
    seccion.classList.remove("hidden");
    const banner = $("estado-banner");
    banner.className = "banner error";
    banner.textContent = msg;
    pintarLista($("lista-mensajes"), []);
    pintarLista($("lista-advertencias"), []);
}

document.addEventListener("DOMContentLoaded", () => {
    cargarCatalogo();
    $("rig-form").addEventListener("submit", validar);
    $("btn-exportar").addEventListener("click", exportar);
});
