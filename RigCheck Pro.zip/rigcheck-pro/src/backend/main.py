"""
RigCheck Pro - CLI de demostracion
==================================
Permite probar el motor desde la terminal:

    python -m src.backend.main              # menu interactivo
    python -m src.backend.main 1 1 1        # validacion directa de IDs

Tambien sirve como ejemplo de integracion para el frontend.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Permite ejecutar el archivo como script suelto
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from src.backend.database import Database, listar  # noqa: E402
from src.backend.rigcheck_engine import RigCheckEngine  # noqa: E402


def imprimir_catalogo(db: Database) -> None:
    print("\n=== CPUs disponibles ===")
    for c in listar(db, "cpus"):
        print(f"  [{c['id_cpu']}] {c['nombre']:30s} socket={c['socket']:8s} "
              f"score={c['power_score']:3d}  ${c['precio_cop']:>12,.0f} COP")

    print("\n=== GPUs disponibles ===")
    for g in listar(db, "gpus"):
        print(f"  [{g['id_gpu']}] {g['nombre']:30s} vram={g['vram_gb']:2d}GB "
              f"score={g['power_score']:3d}  ${g['precio_cop']:>12,.0f} COP")

    print("\n=== Placas base disponibles ===")
    for m in listar(db, "motherboards"):
        print(f"  [{m['id_mobo']}] {m['nombre']:30s} socket={m['socket']:8s} "
              f"formato={m['formato']:10s}  ${m['precio_cop']:>12,.0f} COP")


def imprimir_resultado(resultado) -> None:
    print("\n" + "=" * 60)
    print(f"  RIGCHECK PRO - Resultado de la validacion")
    print("=" * 60)
    print(f"  Estado:        {resultado.estado}")
    print(f"  Compatible:    {'Si' if resultado.compatible else 'No'}")
    if resultado.ratio_rendimiento is not None:
        print(f"  Ratio CPU/GPU: {resultado.ratio_rendimiento}")
    if resultado.diagnostico_balance:
        print(f"  Balance:       {resultado.diagnostico_balance}")
    print(f"  Presupuesto:   ${resultado.presupuesto_total_cop:,.0f} COP")

    if resultado.mensajes:
        print("\n  Detalles:")
        for m in resultado.mensajes:
            print(f"    - {m}")
    if resultado.advertencias:
        print("\n  Advertencias:")
        for a in resultado.advertencias:
            print(f"    ! {a}")
    print("=" * 60 + "\n")


def menu_interactivo(engine: RigCheckEngine) -> None:
    imprimir_catalogo(engine.db)
    try:
        id_cpu = int(input("\nID de la CPU: "))
        id_gpu = int(input("ID de la GPU: "))
        id_mobo = int(input("ID de la placa base: "))
        watts = input("Watts de la fuente (Enter para omitir): ").strip()
        watts_fuente = int(watts) if watts else None
    except ValueError:
        print("Entrada invalida.")
        return

    resultado = engine.validar_rig(id_cpu, id_gpu, id_mobo, watts_fuente)
    imprimir_resultado(resultado)

    salida = engine.exportar_excel(resultado, "Asesoria_RigCheck.xlsx")
    print(f"Reporte exportado a: {salida.resolve()}")


def main() -> int:
    engine = RigCheckEngine()

    if len(sys.argv) >= 4:
        id_cpu, id_gpu, id_mobo = (int(x) for x in sys.argv[1:4])
        watts_fuente = int(sys.argv[4]) if len(sys.argv) >= 5 else None
        resultado = engine.validar_rig(id_cpu, id_gpu, id_mobo, watts_fuente)
        imprimir_resultado(resultado)
        salida = engine.exportar_excel(resultado, "Asesoria_RigCheck.xlsx")
        print(f"Reporte exportado a: {salida.resolve()}")
    else:
        menu_interactivo(engine)

    engine.db.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
