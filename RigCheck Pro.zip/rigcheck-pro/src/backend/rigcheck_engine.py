"""
RigCheck Pro - Motor de validacion de configuraciones de PC
===========================================================
Este modulo implementa fielmente el algoritmo descrito en:
  - docs/pseudocodigo.md
  - docs/diagrama_flujo.png

Pasos del algoritmo (ver pseudocodigo y diagrama):
  1. Validacion fisica: el socket de la CPU debe coincidir con la placa base.
  2. Calculo de cuello de botella: ratio = power_score_cpu / power_score_gpu.
  3. Validacion electrica: la fuente debe cubrir el consumo minimo de la GPU
     (extension respecto a la version original, soportada por la columna
     consumo_min_fuente del esquema).
  4. Calculo del presupuesto total en COP.
  5. Exportacion del resultado a Excel.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

import pandas as pd

from .database import Database, obtener


# ---------------------------------------------------------------------------
# Tipos de datos
# ---------------------------------------------------------------------------

@dataclass
class ResultadoValidacion:
    """Resultado estructurado de una validacion de rig."""

    compatible: bool = True
    estado: str = "Compatible"
    mensajes: list[str] = field(default_factory=list)
    advertencias: list[str] = field(default_factory=list)

    cpu: Optional[dict] = None
    gpu: Optional[dict] = None
    motherboard: Optional[dict] = None

    ratio_rendimiento: Optional[float] = None
    diagnostico_balance: Optional[str] = None
    presupuesto_total_cop: float = 0.0

    def como_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------------------
# Motor principal
# ---------------------------------------------------------------------------

class RigCheckEngine:
    """Encapsula el algoritmo ValidarRig descrito en el pseudocodigo."""

    UMBRAL_CUELLO_CPU = 0.85   # ratio < 0.85  -> CPU debil para la GPU
    UMBRAL_CUELLO_GPU = 1.25   # ratio > 1.25  -> GPU limita a la CPU

    def __init__(self, db: Optional[Database] = None) -> None:
        self.db = db or Database()

    # ----- API publica --------------------------------------------------

    def validar_rig(
        self,
        id_cpu: int,
        id_gpu: int,
        id_mobo: int,
        watts_fuente: Optional[int] = None,
    ) -> ResultadoValidacion:
        """Ejecuta el algoritmo ValidarRig sobre los IDs recibidos."""

        cpu = obtener(self.db, "cpus", id_cpu)
        gpu = obtener(self.db, "gpus", id_gpu)
        mobo = obtener(self.db, "motherboards", id_mobo)

        resultado = ResultadoValidacion(cpu=cpu, gpu=gpu, motherboard=mobo)

        # --- Validacion: existencia de los componentes ------------------
        if not cpu or not gpu or not mobo:
            resultado.compatible = False
            resultado.estado = "Error"
            resultado.mensajes.append(
                "No se encontraron uno o mas componentes en la base de datos."
            )
            return resultado

        # --- 1. Validacion fisica del socket ----------------------------
        if cpu["socket"] != mobo["socket"]:
            resultado.compatible = False
            resultado.estado = "Incompatible"
            resultado.mensajes.append(
                f"Error de socket: el procesador {cpu['nombre']} ({cpu['socket']}) "
                f"no encaja en la placa base {mobo['nombre']} ({mobo['socket']})."
            )
            # Segun el diagrama: si falla el socket, retornamos Falso
            # pero igualmente registramos el presupuesto y exportamos.
            resultado.presupuesto_total_cop = self._presupuesto(cpu, gpu, mobo)
            return resultado

        resultado.mensajes.append(
            f"Socket {cpu['socket']} compatible entre CPU y placa base."
        )

        # --- 2. Calculo del ratio de rendimiento ------------------------
        ratio = cpu["power_score"] / gpu["power_score"]
        resultado.ratio_rendimiento = round(ratio, 3)

        if ratio < self.UMBRAL_CUELLO_CPU:
            resultado.diagnostico_balance = "Cuello de botella: CPU debil para esta GPU"
            resultado.advertencias.append(
                "Advertencia: el procesador limitara el rendimiento de la tarjeta grafica."
            )
        elif ratio > self.UMBRAL_CUELLO_GPU:
            resultado.diagnostico_balance = "La GPU limita el potencial de la CPU"
            resultado.advertencias.append(
                "Advertencia: la tarjeta grafica se queda corta para el procesador elegido."
            )
        else:
            resultado.diagnostico_balance = "Configuracion equilibrada: potencia optima"
            resultado.mensajes.append("Balance CPU/GPU optimo.")

        # --- 3. Validacion electrica (extension de valor) --------------
        consumo_estimado = cpu["consumo_watts"] + gpu["consumo_min_fuente"]
        if watts_fuente is not None:
            if watts_fuente < consumo_estimado:
                resultado.advertencias.append(
                    f"Advertencia: la fuente de {watts_fuente}W es insuficiente. "
                    f"Se recomiendan al menos {consumo_estimado}W."
                )
            else:
                resultado.mensajes.append(
                    f"Fuente de {watts_fuente}W suficiente "
                    f"(consumo estimado {consumo_estimado}W)."
                )
        else:
            resultado.mensajes.append(
                f"Fuente recomendada: minimo {consumo_estimado}W."
            )

        # --- 4. Presupuesto total en COP -------------------------------
        resultado.presupuesto_total_cop = self._presupuesto(cpu, gpu, mobo)

        return resultado

    # ----- Exportacion --------------------------------------------------

    def exportar_excel(
        self,
        resultado: ResultadoValidacion,
        ruta_salida: str | Path = "Asesoria_RigCheck.xlsx",
    ) -> Path:
        """Genera un reporte en Excel con varias hojas (resumen + componentes)."""

        ruta_salida = Path(ruta_salida)

        resumen = pd.DataFrame([{
            "Estado":                 resultado.estado,
            "Compatible":             "Si" if resultado.compatible else "No",
            "Diagnostico balance":    resultado.diagnostico_balance,
            "Ratio rendimiento":      resultado.ratio_rendimiento,
            "Presupuesto total (COP)": resultado.presupuesto_total_cop,
            "Mensajes":               " | ".join(resultado.mensajes),
            "Advertencias":           " | ".join(resultado.advertencias),
        }])

        componentes = pd.DataFrame([
            {"Tipo": "CPU",         **(resultado.cpu or {})},
            {"Tipo": "GPU",         **(resultado.gpu or {})},
            {"Tipo": "Motherboard", **(resultado.motherboard or {})},
        ])

        with pd.ExcelWriter(ruta_salida, engine="openpyxl") as writer:
            resumen.to_excel(writer, sheet_name="Resumen", index=False)
            componentes.to_excel(writer, sheet_name="Componentes", index=False)

        return ruta_salida

    # ----- Helpers ------------------------------------------------------

    @staticmethod
    def _presupuesto(cpu: dict, gpu: dict, mobo: dict) -> float:
        return float(cpu["precio_cop"]) + float(gpu["precio_cop"]) + float(mobo["precio_cop"])
