"""
RigCheck Pro - Capa de acceso a datos
=====================================
Soporta dos motores de base de datos:
  - SQLite  (por defecto, no requiere instalacion)
  - MySQL   (opcional, si el evaluador desea usar el esquema original)

La eleccion se controla con la variable de entorno RIGCHECK_DB:
    RIGCHECK_DB=sqlite   ->  usa data/rigcheck.db
    RIGCHECK_DB=mysql    ->  usa las credenciales de RIGCHECK_MYSQL_*
"""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Any, Optional

# Ruta absoluta al directorio /data del proyecto
DATA_DIR = Path(__file__).resolve().parents[2] / "data"
SQLITE_PATH = DATA_DIR / "rigcheck.db"


class Database:
    """Adaptador de base de datos. Devuelve filas como diccionarios."""

    def __init__(self, engine: Optional[str] = None) -> None:
        self.engine = (engine or os.getenv("RIGCHECK_DB", "sqlite")).lower()

        if self.engine == "mysql":
            self._connect_mysql()
        else:
            self._connect_sqlite()

    # ----- Conexiones ---------------------------------------------------

    def _connect_sqlite(self) -> None:
        nueva = not SQLITE_PATH.exists()
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(SQLITE_PATH)
        self.conn.row_factory = sqlite3.Row
        if nueva:
            self._inicializar_sqlite()

    def _inicializar_sqlite(self) -> None:
        """Crea el esquema y carga datos de ejemplo en SQLite."""
        schema = (DATA_DIR / "schema_sqlite.sql").read_text(encoding="utf-8")
        seed = (DATA_DIR / "seed.sql").read_text(encoding="utf-8")
        self.conn.executescript(schema)
        self.conn.executescript(seed)
        self.conn.commit()

    def _connect_mysql(self) -> None:
        try:
            import mysql.connector  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Para usar MySQL instala 'mysql-connector-python' "
                "(pip install -r requirements.txt)."
            ) from exc

        self.conn = mysql.connector.connect(
            host=os.getenv("RIGCHECK_MYSQL_HOST", "localhost"),
            user=os.getenv("RIGCHECK_MYSQL_USER", "root"),
            password=os.getenv("RIGCHECK_MYSQL_PASSWORD", ""),
            database=os.getenv("RIGCHECK_MYSQL_DB", "rigcheck_db"),
        )

    # ----- Operaciones --------------------------------------------------

    def fetch_one(self, query: str, params: tuple[Any, ...] = ()) -> Optional[dict]:
        cursor = self._cursor()
        cursor.execute(query, params)
        fila = cursor.fetchone()
        cursor.close()
        return dict(fila) if fila else None

    def fetch_all(self, query: str, params: tuple[Any, ...] = ()) -> list[dict]:
        cursor = self._cursor()
        cursor.execute(query, params)
        filas = cursor.fetchall()
        cursor.close()
        return [dict(f) for f in filas]

    def _cursor(self):
        if self.engine == "mysql":
            return self.conn.cursor(dictionary=True)
        return self.conn.cursor()

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:
            pass


# ---- Helpers de alto nivel para los componentes ------------------------

def listar(db: Database, tabla: str) -> list[dict]:
    return db.fetch_all(f"SELECT * FROM {tabla} ORDER BY nombre")


def obtener(db: Database, tabla: str, id_item: int) -> Optional[dict]:
    columna_id = f"id_{tabla[:-1]}"  # 'cpus' -> 'id_cpu'
    if tabla == "motherboards":
        columna_id = "id_mobo"
    return db.fetch_one(f"SELECT * FROM {tabla} WHERE {columna_id} = ?", (id_item,))
