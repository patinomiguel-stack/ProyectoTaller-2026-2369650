"""
RigCheck Pro - API HTTP minima (Flask)
======================================
Expone el motor de validacion para que el frontend HTML/CSS/JS pueda
consumirlo. Diseñada para ser opcional: si no se desea levantar el
servidor, el modulo puede usarse directamente desde Python.

    pip install flask
    python -m src.backend.api

Endpoints:
    GET  /api/catalogo                -> componentes disponibles
    POST /api/validar                 -> ejecuta ValidarRig
    POST /api/exportar                -> genera y devuelve un Excel
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from src.backend.database import Database, listar  # noqa: E402
from src.backend.rigcheck_engine import RigCheckEngine  # noqa: E402

try:
    from flask import Flask, jsonify, request, send_file
    from flask_cors import CORS
except ImportError:  # pragma: no cover
    raise SystemExit(
        "Flask no esta instalado. Ejecuta: pip install flask flask-cors"
    )


app = Flask(__name__, static_folder=None)
CORS(app)
engine = RigCheckEngine()


@app.get("/api/catalogo")
def catalogo():
    return jsonify({
        "cpus":         listar(engine.db, "cpus"),
        "gpus":         listar(engine.db, "gpus"),
        "motherboards": listar(engine.db, "motherboards"),
    })


@app.post("/api/validar")
def validar():
    data = request.get_json(force=True) or {}
    try:
        id_cpu = int(data["id_cpu"])
        id_gpu = int(data["id_gpu"])
        id_mobo = int(data["id_mobo"])
    except (KeyError, ValueError, TypeError):
        return jsonify({"error": "Faltan id_cpu, id_gpu o id_mobo"}), 400

    watts = data.get("watts_fuente")
    watts_fuente = int(watts) if watts not in (None, "", "null") else None

    resultado = engine.validar_rig(id_cpu, id_gpu, id_mobo, watts_fuente)
    return jsonify(resultado.como_dict())


@app.post("/api/exportar")
def exportar():
    data = request.get_json(force=True) or {}
    try:
        id_cpu = int(data["id_cpu"])
        id_gpu = int(data["id_gpu"])
        id_mobo = int(data["id_mobo"])
    except (KeyError, ValueError, TypeError):
        return jsonify({"error": "Faltan IDs"}), 400

    watts = data.get("watts_fuente")
    watts_fuente = int(watts) if watts not in (None, "", "null") else None

    resultado = engine.validar_rig(id_cpu, id_gpu, id_mobo, watts_fuente)
    salida = Path("Asesoria_RigCheck.xlsx").resolve()
    engine.exportar_excel(resultado, salida)
    return send_file(salida, as_attachment=True)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
